# Stage 1.1.0 performance investigation

Read-only investigation against HEAD `8567c75`, 2026-10-19. No app/source/asset edits, installs, launches, commits, or global plugin configuration changes. The parent owns app probes. CLI files, one isolated dependency, and capture reports are under `.work`.

## What the evidence says

- `GardenScene.kt:143-159` measures the `withFrameNanos` callback interval and only the local `garden.tick` wall/thread CPU time. It deliberately excludes later native rendering, GPU completion, and compositor presentation. The parent’s 22–111 ms callback p50 / approximately 133 ms p95 with approximately 1.3 ms local wall time supports looking beyond Kotlin route math; it does **not** establish GPU-bound rendering.
- Current native workload for garden + one ladybug + one beetle is 418,932 GLB triangles and 325 primitives before sky/sparks/other UI. The original native implementation at `0ea4d05` used 29,690 triangles and 45 parts for the equivalent trio. This is the earliest native commit inspected, not a verified mapping of the user’s named “firstversion.”
- Current GLBs: garden 251,260 triangles / 36 mesh primitives; ladybug 71,428 / 139; beetle 96,244 / 150; butterfly 55,688 / 68; caterpillar 117,128 / 92. Ladybug and beetle each have a 34-joint skin, with 102 channels in every native clip. Imported mesh count is not a measured GPU draw count, but it is a concrete submission/scene-work multiplier.
- At `0ea4d05`, garden had 26,704 triangles / 16 parts; ladybug 1,472 / 14; beetle 1,514 / 15; butterfly 1,560 / 12; caterpillar 4,344 / 25. The old app also wrote opacity every tick. Unchanged opacity writes are therefore not a newly introduced operation, but their possible hierarchy cost now scales over many more descendants.
- `GardenRuntime.kt:196-200` writes position, orientation, scale, animation state, and opacity for each resident each frame. Normal resident opacity reaches exactly 1 after the arrival fade and is then repeatedly set to 1.
- `ModelLibrary.kt:268` at `8567c75` forwards each opacity write without a value guard. `javap` of installed SDK 6.1.0 verifies `OpacityControllerComponent.setOpacity` unconditionally enters `Component.enqueueBatchSetCall`. The latter marks the component dirty (`componentDirtyAdd`) at the frame sync point before invoking the cache setter; outside that batching path it invokes cache/native setters. There is no value equality comparison in these inspected wrapper/batching methods. Native-side deduplication and hierarchy traversal cost remain unverified.
- `ModelLibrary.kt:262` at `8567c75` forwards loop speed every frame. SDK `AnimationPlaybackController.setSpeed` directly forwards to foundation `AnimationController.setPlaySpeed`, also without a wrapper equality check. The animation plan comparison does prevent restarting unchanged clips every frame. Current two residents (ladybug + beetle) use zero crossfade duration, so butterfly/caterpillar retired crossfade-player buildup cannot explain that two-resident probe.
- `GardenHitTarget.kt` constructs one box collider, one interactable, and one HoverEffectComponent per resident. It does not cook one collider per imported mesh and does not update the collider in the tick. Removing hover alone is a useful separate probe if stutter is gaze-dependent; current evidence does not establish hover as the root cause.

## Highest-yield one-variable probe

Suppress **only unchanged opacity writes** in `InsectModel.opacity`, using a Kotlin cached last-applied value initialized to the component’s initial 1f. Clamp the requested value, return when it equals the cached value, and update the cached value after the component write. Do not use the component getter for the comparison because that can itself enter SDK synchronization. Preserve all fades and keep meshes, animation, hover, sky depth state, device state, and residents identical.

Capture a steady 20–30 second baseline and probe while actually in the garden with the same two residents and head/gaze position, after arrival fades. Compare app callback cadence plus Perfetto spatial CPU/GPU stage distributions. Treat no material improvement as a falsified opacity-dirtying hypothesis, then test one separate variable (e.g. temporarily pause native clips while preserving movement, or disable hover if gaze-dependent). Do not bundle speed deduplication with the opacity probe.

## Working PICO CLI profiler without global setup

The installed CLI already bundles the compatible archive:

`C:/Users/Admin/AppData/Roaming/npm/node_modules/@pico-fe/pico-cli/vendor/profiler-cli/pspp-profiler-cli-0.2.0.tgz`

It was safely extracted to `.work/stage110-profiler-cli-0.2.0/package`. Its self-contained `dist/index.js` executes successfully without npm install. PICO CLI’s supported `PICO_CLI_PROFILER_ENTRY_PATH` override selects it process-locally.

`perf doctor check` found ADB when `ADB_PATH` was supplied, but no Trace Processor. To avoid the doctor installer’s persistent user PATH edit, its exact pinned official Perfetto binary was downloaded into `.work/stage110-profiler-cli-0.2.0/trace_processor_shell.exe`, using the URL and checksum from the bundled installer:

- URL: `https://commondatastorage.googleapis.com/perfetto-luci-artifacts/v49.0/windows-amd64/trace_processor_shell.exe`
- Verified SHA-256: `a881f3e2d4c6131493e85bfd1f36d1efe58e1478e2991825418d5d21614c1e48`
- Executed `--version`: `Perfetto v49.0-33a4fd078`; RPC API version 14.

Exact supported PowerShell flow (all command/option names checked with this executable’s help; recording/loading is left to the parent to avoid overlapping captures):

```powershell
$env:PICO_CLI_PROFILER_ENTRY_PATH = 'C:\Work\AndoidSpatialProject\BugWorld\.work\stage110-profiler-cli-0.2.0\package\dist\index.js'
$stage110Cli = 'C:\Users\Admin\AppData\Roaming\npm\pico-cli.ps1'
$stage110Adb = 'C:\PICO4Overseas\platform-tools-latest-windows\platform-tools\adb.exe'
$stage110Tps = 'C:\Work\AndoidSpatialProject\BugWorld\.work\stage110-profiler-cli-0.2.0\trace_processor_shell.exe'

& $stage110Cli perf trace record --adb $stage110Adb --device PB322XKGL4220049B --package com.bugworld.app --duration 20 --output '.work\stage110-baseline.perfetto-trace'
& $stage110Cli perf trace load '.work\stage110-baseline.perfetto-trace' --shell $stage110Tps --envelope

# Substitute the returned session id below.
& $stage110Cli perf trace analysis frame.spatialOverview --session SESSION_ID --table-format
& $stage110Cli perf trace analysis frame.appOverview --session SESSION_ID --package com.bugworld.app --fps 90 --table-format
& $stage110Cli perf trace analysis frame.appBusyRunnings --session SESSION_ID --package com.bugworld.app --fps 90 --limit 20
& $stage110Cli perf trace analysis frame.spatialSlowest --session SESSION_ID --limit 20
& $stage110Cli perf trace analysis report.overview --session SESSION_ID --package com.bugworld.app --output '.work\stage110-baseline-overview.html'
& $stage110Cli perf session close SESSION_ID
```

The default trace preset includes scheduler events, CPU/GPU frequency, GPU memory, atrace gfx/view, all atrace apps, process statistics, and system statistics. The bundled README documents `frame.spatialOverview` as reporting spatial frame types, abnormal frames, and CPU/GPU stage total/average/max/p50/p90/p95/p99. Actual stage data availability on this device still requires a trace. `BugWorldStage:tick` is already an Android Trace section and should permit correlation with app/main-thread work.

## Live capture result and limitation

Ran 15 seconds via the extracted executable (`stage110-live-perf.json`) and then 20 seconds through PICO CLI plus process-local override (`stage110-live-perf-enabled.json`). For the latter, the parent explicitly authorized temporary `debug.sprt.fps.log=1`; original value was empty and was restored in a finally block, then verified empty.

Both captures ran and saved reports, but all app FPS / compositor FPS / GPU fields were N/A. They are **not usable performance baselines**. The first capture had app CPU 0%; the second had 0–3.3% sampled app CPU. Recent logs after enabling FPS contained `com.picoxr.systemenv-session` at 61–62, `com.picoxr.worldspace` at 1, and `Server:SpatialRuntime` at 2; there were no BugWorld StagePerf or app FPS lines in that recent window. This suggests the target garden was inactive during capture, but does not prove why.

The live CLI app parser matches `Spatial FPS:` lines for the selected package. Its runtime/GPU parser instead requires `PxrMetric` entries (`FPS=`, `GPU=`, GPU frequency/temperature). `Server:SpatialRuntime` lines alone do not populate the live compositor/GPU columns. Therefore a N/A live field is not zero FPS and not proof of missing device support; prefer the trace workflow above for CPU/GPU stage attribution.

Re-run live capture while garden is visibly active if useful:

```powershell
& $stage110Cli perf live run --package com.bugworld.app --adb $stage110Adb --device PB322XKGL4220049B --duration 20 --save --output '.work\stage110-active-live.json'
```

For app FPS logs, save the existing device property, temporarily set `debug.sprt.fps.log` to 1, and restore its exact previous value. `--save` is required with `--output` by this shipped executable’s help, despite some README examples omitting it.

## Opacity-only probe follow-up

2026-10-19T10:59:04.566364+00:00: Parent reported the 1.0.9 opacity-only probe installed, with sky depth writing preserved. One bounded 15-second fresh logcat observation produced zero BugWorldStagePerf/BugWorldGarden lines. Stage foreground activity was unverified, so no trace was recorded and no repeated inactive sampling was performed. This is an unavailable comparison, not evidence that the probe passed or failed. Package presence was not rechecked in this phase. See `stage110-opacity-phase-comparison.json`. A future trace adds instrumentation overhead and should be compared under matching settings.


## User result: unchanged-opacity probe failed

The parent relayed the user's explicit observation after the opacity-only build: **no stutter before insects load; severe stutter after they load**. Suppressing repeated unchanged opacity writes did not resolve the reported problem. This falsifies it as a sufficient fix, not every possible opacity-related native cost. No valid quantitative foreground FPS trace was obtained, so there is no numeric before/after FPS claim. The original failed gate observation above is retained.

## Local clone / skin / material investigation (no device access)

- A retained preload source is disabled and is never attached to the Garden root or passed to app `playAnimation`. Only the returned clone is attached and played. The inspected SDK clone wrapper calls native `Entity.clone(recursive, !shouldShareMaterialInstance)` and copies/registers components; it contains no animation-play call. Local evidence does **not** support the claim that the original and clone both run players. Native importer/renderer behavior cannot be ruled out from wrapper bytecode alone.
- Each insect GLB contains one scene rig, one skin, and five global animation clips. All 139 ladybug mesh nodes and all 150 beetle mesh nodes reference skin 0; both skins have 34 joints. Every clip targets those 34 nodes with 102 channels. Butterfly has 68 skinned mesh nodes / 25 joints; caterpillar 92 / 15. Full results are in `stage110-model-structure.json`.
- Exact *SDK-imported animation resource owner count* is unavailable offline. `getAnimationResources()` queries the native owner. The app traverses the imported hierarchy and deduplicates resources by name, keeping the highest encountered owner. It initiates one current playback controller per insect. Ladybug/beetle plan transitions have zero fade, stop and close the previous controller immediately, and do not retain crossfade players. Five available clip resources do not imply five simultaneous players.
- All insect GLB material alpha modes are OPAQUE, and all are double-sided. Ladybug/beetle each have only 10 authored materials despite 139/150 mesh parts. The native material-instance count after cloning has not been measured. `shouldShareMaterialInstance=false` requests material cloning; whether that duplicates once per distinct source material or once per mesh slot is not exposed by the wrapper.
- Existing `isolatePaintMaterials` already clones and retains the painted material slots separately, then assigns each copied material only to eligible meshes. Therefore insect clone material sharing is a small *candidate* probe that could preserve geometry, shading values, animation, and independent artwork. It needs native instance-count/timing evidence; do not claim 139/150 separate material instances from the GLB counts.
- An OpacityControllerComponent with value 1 remains on each model root after the write-cache probe. Local SDK bytecode exposes the property transfer but not render-pass classification. There is no evidence here that opacity 1 forces transparent passes. All-opaque authored material metadata does not prove what the renderer ultimately does with the component.

## Focused next step after UI recovery

Obtain the active-stage trace first. If another app-only isolation is needed for the remaining opacity-component hypothesis, **detach the root OpacityControllerComponent only at fully opaque value 1, reattach it only while the requested opacity is below 1**, preserving the exact fade values and other scene behavior. Use a local attachment-state cache; leave the existing model, native clips, transforms, materials, hover, and sky unchanged. This is more direct than setter caching for testing whether *the presence of that component* carries steady-state render cost. It should preserve the fully opaque appearance and fade behavior, but native attachment/removal semantics still require visual confirmation. Measure the steady-state period after the arrival fade, and do not combine this with the material-sharing flag probe. No such change was implemented by this investigation.

## Executed profiler command inventory

Saved exact argument arrays and results in `stage110-perf-command-inventory.json`.

- **2 actual top-level PICO CLI perf invocations:** `perf live run` (20 seconds, report saved, no usable active Stage FPS) and `perf doctor check` (exit 1: ADB found, TPS then missing).
- **8 direct invocations of the bundled profiler executable:** 6 help calls, 1 doctor check, 1 live run (15 seconds, no usable active Stage FPS).
- Nominal live collection duration total: 35 seconds. No `trace record`, `trace load`, or frame analysis was actually executed; those were documented commands only. One later direct-ADB gate observed 15 seconds without fresh Stage logs and did not start a trace.
- Separate local verification: one Trace Processor `--version` invocation. No global dependency installer was run. These totals cover only this subagent's session, excluding parent commands.
