SELECT p.name AS process, t.name AS thread, t.tid,
       ROUND(SUM(s.dur) / 1e9, 6) AS scheduled_cpu_seconds,
       ROUND((SELECT end_ts-start_ts FROM trace_bounds) / 1e9, 6) AS trace_seconds,
       ROUND(SUM(s.dur) * 100.0 / (SELECT end_ts-start_ts FROM trace_bounds), 3) AS one_core_percent
FROM sched s JOIN thread t USING(utid) JOIN process p USING(upid)
WHERE s.dur > 0 AND
      ((p.name = 'com.pico.spatial.runtime' AND t.name = 'Eng-Render')
       OR (p.name = 'com.bugworld.app' AND t.tid = p.pid))
GROUP BY t.utid;
