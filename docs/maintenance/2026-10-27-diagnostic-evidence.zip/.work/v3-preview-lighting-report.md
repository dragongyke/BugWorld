# V3 preview and native scene lighting

Scope is limited to `ui/PreviewScene.kt` and `spatial/SceneLighting.kt`.

## Preview integration

- Shares initialized templates via `ModelLibrary(state.app, state.templates)`.
- Artwork loading is now suspending: preload the approved GLB, create `InsectModel(library, requestedAsset, null)`, await `updateTextureSuspend(rawBitmap)`, obtain real bounds, then attach. The old preview remains until replacement is ready.
- New instances close in `finally` if upload, cancellation, bounds validation, or native attachment fails. A disposed runtime is checked after suspensions. Full scene errors close the runtime; normal revision cancellation cleans only the pending instance. Runtime/model/library close order remains instances before cache.
- Initial model/control visibility is deferred until their first valid placement, avoiding a frame at the spatial origin.
- `PreviewRuntime.active` forwards lifecycle + native onstage state to `InsectModel.setActive`, pausing the native clip clock while hidden. A newly cloned model inherits this state both before upload and after the suspension before attachment; frame updates also reject inactive/closed scenes.
- Drawing-area anchor is `(0.5 * width, 0.43 * height)`, forward Z is `240.dp`, target largest model extent is `300.dp * previewScale`. Controls sit 96dp above the paper's bottom at the same depth. Native `convertPosition` / `convertSize` still handle pixel-to-spatial conversion.

## Scene lighting

- Native directional main light uses `castsShadowEnabled=true`, `ShadowProjectionType.Auto()`, BACK shadow-face culling, and `.005f` bias. The weaker opposite fill does not create a second shadow set.
- Initial native lux settings: garden warm key 1200 and cool fill 420; preview near-white key 1600 and cool fill 500. These are starting native render parameters, not Blender-equivalent or device-validated exposure claims.
- Dusk background exclusively decodes `v3/environment/sky.png`; no old sky or fallback path remains. It uses an inward-visible Unlit sphere, disabled depth writes, and no tone mapping. This is a background image, not an IBL environment. The [official material guide](https://developer.picoxr.com/document/spatial-sdk/material/) states Unlit does not cast or receive shadows.
- SceneLighting owns a subtree, retains texture/mesh/material resources, keeps the sky bitmap until texture close, cleans partial-construction failures, and closes idempotently. It tolerates the parent already being destroyed via the real Kotlin `Entity.valid` property.

## Verification

- The actual SceneLighting source compiled against cached PICO 6.1.0 core + native foundation, Kotlin 2.1.20, Android 35. Output `.work/v3-ui-probe/lighting.jar`; compiler output `.work/v3-ui-probe/lighting-compile.log`.
- First probe caught the `javap` naming trap: JVM `isValid()` is exposed to Kotlin as `valid`, not a callable `isValid()`. Corrected and compilation succeeded.
- Repeated the isolated compile after final native-attachment Boolean checks: final SceneLighting source passes with exit 0. PreviewScene (including the final native-animation active-state propagation) awaits the coordinated full app compile once root's route integration is ready.
- `git diff --check` reported no whitespace errors (repository CRLF conversion warnings only).
- Full app compilation is coordinated by root; no concurrent Gradle task was started here. Native cancellation/render behavior cannot be exercised without the SDK runtime/device, so no fake source-literal tests were added.

No GardenRuntime or other production files modified by this follow-up. No commits or device operations.
