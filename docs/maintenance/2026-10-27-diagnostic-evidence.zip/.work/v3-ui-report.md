# V3 spatial UI implementation

Scope: `Main.kt`, `WorkspaceWindows.kt`, `ui/StudioScreen.kt`, `ui/AlbumScreen.kt`, `WorkspaceWindowsTest.kt`, and 15 approved UI PNGs under `app/src/main/assets/v3/ui`.

- Replaced the independent `BugWorldSpeciesBar` window with `com.pico.spatial.ui.design.windows.TabBar` inside the paper composition. The right tools and left album remain independent windows; the existing callbacks remain intact.
- The TabBar uses the supplied outlined BugWorld logo, four supplied optical insect icons, album icon, and crayon icon. Seven items fit the SDK's explicit limit. Shared action and tool icons load the supplied PNG assets with tinting for active/disabled states. All procedural legacy line icons and the outline-sheet-as-navigation-icon shortcut are gone. New-paper and delete actions use text because the approved pack has no matching icons.
- Applied approved ink, muted, accent, border, and paper palette; added the supplied save, preview, leaf, and crayon icons to paper/album actions. Album details use the approved species icon, while gallery cards retain the real saved artwork.
- Aligned all 12 swatches with the approved board; selected/default purple is `0xFF986BD3.toInt()` (root coordinating state default). With root approval, added an explicit `openCanvas` callback to `ToolScreen` and a visible `回到画纸` action, so users can recover a closed paper even when the attached TabBar and album are both absent.
- Preserved repeated Stage restoration, with a fix for a native window opening after Stage launch captured its initial window set.

## SDK evidence

Inspected the local Gradle `com.pico.spatial.ui:design:6.1.0` AAR using JDK `javap`. Full signatures saved in `.work/v3-ui-probe/api.txt`.

- `TabBar(followViewpoints, focusable, extraContentHeight, content: TabBarScope.() -> Unit)`.
- `TabBarScope.item(selected, onClick, mainContent, modifier, badge, supportContent, extraContent)`.
- `TabBarDefaults.ItemsCountLimit = 7`.
- Bytecode calls `AugmentImpl` at `NormalizedPoint3D.TopFront` / `AugmentContentAlignment.TopCenter` with `SpatialWindowType.Tabbar`, establishing that this is an attached SDK TabBar, not a separately positioned container.

## Verification

- RED: isolated JUnit run produced one expected failure, `lateWindowAttachmentIsPreservedAcrossStageDisposal`, because the late tools window was missing from `[paper]`.
- GREEN: same isolated production-code compilation and JUnit run passed **8 tests**, including the late-attachment regression and repeated Stage transitions preserving explicit closes. Logs: `.work/v3-ui-probe/red.log`, `.work/v3-ui-probe/green.log`.
- SHA-256 comparison: all **15 PNG files exactly match** their approved review source files.
- `git diff --check`: no whitespace errors (repository CRLF conversion warnings only).
- Root integration run `.work/v3-artwork-red.log`: `:app:compileDebugKotlin` succeeded, validating the actual TabBar, Compose signatures, and asset-image integration. Its classes were written at 12:52:04; final tools restore callback/palette edits at 12:52:10 need the next compile.
- That root run then failed in `:app:compileDebugUnitTestKotlin` on the parallel work-in-progress `ArtworkMigrationTest` unresolved `ArtworkMigration`, and `ArtworkRasterMapperTest` unresolved `javax.imageio.ImageIO`; no UI compile errors. Full unit suite, lint, and APK review remain coordinated by root.

## Remaining verification limits

- No device use. Native TabBar default material/hover appearance and true spatial window placement need headset validation; the approved board remains a visual design reference, not a runtime screenshot.
- Paper size comes from the existing manifest (860x780). Root owns the manifest and can align its aspect ratio with the approved wider paper panel during integration.

No commits, pushes, legacy model/state/paint edits, or root-script modifications made by this subtask.
