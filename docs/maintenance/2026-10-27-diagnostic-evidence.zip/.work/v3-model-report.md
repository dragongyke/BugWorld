# Native GLB model replacement

Implemented in the three assigned files only:

- `app/src/main/java/com/bugworld/app/spatial/ModelLibrary.kt`
- `app/src/main/java/com/bugworld/app/spatial/AnimationClipPolicy.kt`
- `app/src/test/java/com/bugworld/app/AnimationClipPolicyTest.kt`

Supporting API evidence is in `.work/v3-native-api.md`; isolated compiler scripts and jars are under `.work/v3-native-probe/`.

## Integration contract

```kotlin
val library = ModelLibrary(context, state.templates) // optional shared templates avoids duplicate bitmap decoding
library.preload("v3/butterfly")                     // suspend, uses assets/v3/models/butterfly.glb
val next = InsectModel(library, "v3/butterfly")      // synchronous clone of already-loaded GLB
try {
    next.updateTextureSuspend(rawPaintBitmap)       // worker projection, main-thread SDK upload
    parent.addChild(next.root)
} catch (failure: Throwable) {
    next.close()                                   // also on cancellation before attachment
    throw failure
}
```

**Required packaging:** `androidResources.noCompress += "glb"`, because `preload` uses `assets.openFd()` to avoid copying the 63 MB garden into a JVM byte array. No Editor conversion is needed. `key(name)` accepts existing prefixes by resolving the final segment, but always reads the reviewed `v3/models/*.glb`.

Preserved `InsectModel` interfaces: constructor with optional bitmap, `root`, `pose(...)`, `opacity(...)`, `updateTexture(Bitmap)`, `animate(time, flying, open, reaction)`, `animate(InsectAnimationFrame)`, `close()`. Added `updateTextureSuspend(Bitmap)` and `setActive(Boolean)`. Root should use the suspend texture version and pass no bitmap to the constructor; the sync path exists only for compatibility.

Preload serializes model loads, retains source mesh/material resources, and disables source hierarchies. Clones recursively use `shouldShareMaterialInstance=false`. The cache must outlive every model instance; close instances before the library.

## Resulting model behavior

- Actual reviewed GLBs are the only geometry source. JSON reconstruction, `MeshModel`, procedural appendage movement, and `LegacyInsectAnimation` imports/calls are removed.
- Insects use an extra parent transform: maximum X/Z span becomes 0.48 m, horizontal center becomes zero, minimum Y becomes zero. The imported rig and all its local transforms stay intact. Garden's normalization transform is identity.
- Paint eligibility uses `ArtworkRasterMapper.materialMeshes(species)` for both exact material and node names. Shared exceptions remain restricted to the intended head meshes.
- Each painted material is isolated through a temporary native entity clone, then retained with `toGlobal()` and installed only in eligible slots. This preserves imported normal/roughness and internal PBR fields without reconstructing a material in code. Updated base-color factor is neutral white.
- Mapper output bitmaps are retained for the lifetime of their textures because the SDK's immediate bitmap-copy semantics were not proven. Updating/closing closes textures and recycles these outputs. Suspend mapping copies the borrowed input before the worker, recycles unuploaded results on cancellation/failure, and checks `closed` before upload.
- Missing imported material/node bindings or any of the five exact animation names cause a descriptive error and instance cleanup. There is no legacy geometry fallback.

## Authored animation policy

All animation resources come from the imported entity hierarchy, with their supplying entity stored as the playback owner. For duplicate names from child aliases, the first/topmost owner is selected; each reviewed insect has one rig. Runtime owner names are logged.

| Species | Runtime mapping |
|---|---|
| Beetle / ladybug | idle→`idle`; walk/turn→`walk`; touch/recoil→`touch`; takeoff→`takeoff`; flight→`flight`; land→reverse sampling of `takeoff` |
| Butterfly | idle/ground fallback/land→`butterfly_idle_perch`; takeoff/recoil→`butterfly_startle`; flight→`butterfly_fly`; touch→`butterfly_perch_touch`; perch/explore→`butterfly_antenna_groom` |
| Caterpillar | idle/unsupported flight states→`caterpillar_idle_breathe`; crawl/walk/turn→`caterpillar_crawl`; explore→`caterpillar_explore`; touch/perch→`caterpillar_touch_curiosity`; recoil→`caterpillar_recoil` |

Loop variants are created once with `repeat(SpatialAnimation.INFINITE)`. Finite responses and takeoff/landing are paused native animation controllers sampled by `setTime(duration * phase)` so they follow the existing behavior controller's progress. Interrupted shell takeoff/landing starts at the current sampled phase. No reverse-speed assumption is needed. Shell species use zero blend to avoid introducing unreviewed in-between wing/shell intersections. Butterfly/caterpillar loop changes use 0.12 s crossfades. Open preview freezes the authored idle frame at t=0; it does not flatten the mesh or change bone transforms.

Perching deliberately makes grooming/curiosity reachable through the existing behavior controller; otherwise those clips would only be reachable through action enums that controller never emitted for those species.

## Verification

- API probe: `.work/v3-native-probe/compile.ps1` → exit 0, actual cached PICO 6.1.0 core jar.
- Actual model + policy + real drawing mapper/template sources: `.work/v3-native-probe/compile.ps1 -Model` → exit 0 on final source (Kotlin 2.1.20 / JVM 11 / Android 35). Output `model.jar`.
- `.work/v3-native-probe/test-policy.ps1` → **OK (5 tests)**, exit 0. Tests validate five exact reviewed GLB clip names per species, mapping, reverse landing, interruption start phase, no shell crossfade, caterpillar ground-only behavior, perching reachability, and finite frozen preview sampling. Tests were observed red before implementation and before the perching fix.
- `git diff --check -- app/src/main/java/com/bugworld/app/spatial/ModelLibrary.kt` → exit 0.
- No full Gradle build, device install, commit, GLB edit, or unrelated app edit was performed by this subtask.

## Remaining native verification

Compilation proves API shape only. The first device run should verify importer animation-owner placement, cloned skin bindings, seeking while paused, material isolation, and optional glTF extension appearance. The implementation logs exact imported owners and fails clearly when resources are absent. Garden dew transmission / firefly emission / moss transparency and lighting fidelity remain covered by the API report's compatibility notes.

## Lifecycle follow-up

`InsectModel.setActive(false)` pauses the current native controller, closes pending crossfade controllers, and resets the preview delta-time anchor. While inactive, time-driven preview animation does not advance. If a direct `animate(frame)` request changes the current clip while inactive, that newly created controller is paused immediately and its time is not subsequently sampled. `setActive(true)` resumes looping clips only; finite clips remain paused because their times are explicitly driven by behavior progress, and open-preview poses stay frozen. Calls after close are harmless. Root should call this when visibility/lifecycle state changes, rather than only stopping its frame callback.

Follow-up isolated model compile completed with exit 0; `git diff --check` passed. Only `ModelLibrary.kt` changed in the follow-up; no policy behavior changed. Native pause/resume effects still require the engine/device, so no mock-only controller test was added.

Cancellation/resource review: source caching happens after the awaited native load returns and after material/mesh retention; a closed library rejects and destroys a late result. Mutex serialization prevents simultaneous source loads. Mapping owns its copied input, retains worker results in an outer variable for cancellation cleanup, checks model closure before upload, and transfers output ownership only after upload succeeds. Caller still owns closing an unattached `InsectModel` if cancellation arrives after upload completes. Source mesh/material resources are closed after source entities, and generated texture/material/repeat resources are closed after instance destruction. Keep library lifetime outside all its instances.

## Confirmed authored axes and Euler order

Normalization only translates and uniformly scales. It preserves native model axes: butterfly forward is **-Z**, beetle/ladybug/caterpillar forward is **+X**, and up is **+Y**. Source scripts place butterfly `Head` on Blender +Y, others' heads on +X, and export `export_yup=True`. `pose(x,y,z,yaw,scale,pitch,roll)` passes degrees directly to `EulerAngles(pitch,yaw,roll)`.

The actual cached 6.1.0 math class was executed on the JVM in `.work/v3-native-probe/EulerProbe.java`: `EulerAngles(30,40,50).toQuat()` equals `qY(40) * qX(30) * qZ(50)` with dot product 1.0; all other permutations differ. Thus the matrix is **Ry(yaw) Rx(pitch) Rz(roll)**, acting on a vector with roll first, then pitch, then yaw. Positive yaw 90° maps +X to -Z and -Z to -X. This verified Y-X-Z contract was sent to the surface-route agent.
