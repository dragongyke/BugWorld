# Native v3 image-based lighting

2026-10-09. Changed `SceneLighting.kt`; added `scripts/assets_v3_environment.py` and `app/src/main/assets/v3/environment/sky.ktx`. No model, garden runtime, build configuration, device installation, or SDK installation changed by this agent.

## Runtime integration

Call `lighting.applyTo(model.root)` after attaching the garden model and each new insect instance. It explicitly traverses every `ModelComponent` node, because receiver inheritance is not documented. A base-color repaint does not need rebinding. Daytime/preview lighting returns without installing local IBL. Dusk adds one source at exponent `0f`; both existing directional lights, their lux values, and key-light shadows are unchanged. The original sky PNG remains the unlit visual background.

```kotlin
val texture = TextureResource.load("v3/environment/sky.ktx", LoadType.FROM_ASSETS,
    TextureCreateOption().apply {
        textureEncoding = TextureEncoding.LINEAR
        colorSpace = TextureColorSpace.SRGB
        mipmapMode = TextureMipmapMode.NONE
    })
sourceEntity.components.set(ImageBasedLightComponent(ImageBasedLightSource.Single(texture), 0f))
meshEntity.components.set(ImageBasedLightReceiverComponent(sourceEntity))
```

`NONE` prevents generation of ordinary mipmaps over the offline GGX levels. Encoding and color-space primaries are separate properties: source samples have already been linearized from sRGB. Texture is retained with `toGlobal()`. Shutdown removes surviving receiver components before destroying the source hierarchy and closing the retained texture; dead insect entity wrappers are pruned when binding subsequent instances.

Verified these signatures and enums against actual cached native **core 6.1.0**, including `Entity.ComponentSet.remove(Class)`, receiver `source`, and the two-argument IBL constructor. Full `SceneLighting.kt` compiled with Kotlin 2.1.20, native core/foundation 6.1.0 and Android 35, exit **0**; result `.work/v3-native-probe/lighting.jar` is **7,085 bytes**. The public docs describe [HDR KTX local IBL and receivers](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-image-based-light-component/index.html), [texture encoding/options](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs.resource/-texture-create-option/index.html), and [mipmap generation mode](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs.resource/-texture-mipmap-mode/index.html). They are currently 6.1.9; actual 6.1.0 bytecode and compilation establish compatibility here.

## Conversion and file evidence

Input is the approved 1774×887 RGB **LDR** image, copied byte-identically from the review source. No other environment pixels are used. Conversion linearizes sRGB, resamples the six cubemap faces, computes GGX reflection integrals at five roughness levels, and integrates three-band diffuse SH. It does **not** recover HDR illumination, add highlights, or perform artistic exposure changes. Float pixels remain within [0,1].

The local installed Spatial Editor's `resources/builtin/assets/env/SystemIbl_ibl_brightness.ktx` contains the public Filament profile: R11F_G11F_B10F, 256-square faces, five levels through 16-square, and `sh` metadata with 27 ASCII floats. This matches [Filament cmgen's IBL profile and roughness mapping](https://github.com/google/filament/blob/main/tools/cmgen/src/cmgen.cpp). The converter uses direct GGX importance sampling (the public `--ibl-no-prefilter` integration formulation) rather than box-resized mipmaps; samples per filtered level are 1024, 2048, 4096, 8192. Its nine coefficients include the cosine convolution, polynomial reconstruction factors and Lambertian 1/pi, following the public [SH convention](https://github.com/google/filament/blob/main/libs/ibl/src/CubemapSH.cpp). Orientation matches cmgen's default X mirror; visual alignment with the SDK's generated sphere remains a device check.

The file uses standard [Khronos KTX1 fields](https://registry.khronos.org/KTX/specs/1.0/ktxspec.v1.html). In particular it uses correct `glType=GL_UNSIGNED_INT_10F_11F_11F_REV`, `glTypeSize=4` and `glBaseInternalFormat=GL_RGB`; the legacy cmgen/header in the installed sample uses nonstandard values for these fields, which were not copied. Cubemap internal format and payload profile are the same. No private preprocessing extension is required by the examined public profile.

| Field | Generated value |
|---|---|
| Magic | KTX 1.1, little-endian marker 0x04030201 |
| glType / size | 0x8C3B / 4 |
| glFormat / glInternalFormat / glBaseInternalFormat | 0x1907 / 0x8C3A / 0x1907 |
| Width / height / depth / array elements | 256 / 256 / 0 / 0 |
| Face order | +X, -X, +Y, -Y, +Z, -Z |
| Mip dimensions | 256, 128, 64, 32, 16 |
| Bytes per face at each mip | 262144, 65536, 16384, 4096, 1024 |
| Metadata bytes | 632 |
| Total bytes | 2,095,820 |

SHA-256 source PNG: `5b969de05e7e0265a573a44a68265b39402e9fd174654672fb7bd5604d919215`.

SHA-256 output KTX: `0195977938fe35cf7a6131649ea7e3cd742069e5eedc32ea71fd75623a9220f1`.

Validation succeeded: script analytic checks (sRGB transfer, six face axes, solid-angle integral 4π, constant and directional SH, constant-energy GGX, packed-float known value and round trip); `--check` validates all finite pixels, 27 SH values, source hash, lengths and alignment. An independent Node Buffer parser also walked all **30 face payloads**, confirming the header and final offset **2,095,820** with no trailing bytes. `git diff --check` passed.

Rebuild: `python scripts/assets_v3_environment.py`. Validate without regenerating: `python scripts/assets_v3_environment.py --check`. Requires the existing NumPy/Pillow runtime; no tool downloads were used. Consider adding `ktx` to app `noCompress` alongside the other native assets (root owns build configuration).

## Remaining verification

This establishes API compilation and a structurally/numerically validated floating-point KTX, **not successful native texture loading or rendering**. Device checks remain: PICO loader acceptance of standard KTX fields, visible water/PBR reflection, SH illumination, background-to-reflection orientation, intensity balance, and native memory/performance. No fallback texture or proprietary-format assumption was wired in. The original PNG's limited luminance and panorama seams are retained.
