# V3 paint integration report

Implemented in the assigned drawing/template scope. No Gradle invocation, device action, commit, push, or secondary agent was used.

## Files

- `drawing/Template.kt`: only `v3/templates`, version defaults to 3 and rejects legacy template construction. New documents use the approved mask; old raster input goes through `documentFrom(bitmap, sourceVersion)`. `bitmap(..., true)` uses a mutable bitmap before drawing the outline.
- `drawing/ArtworkRasterMapper.kt`: pure Kotlin pixel-to-UV transfer, protected ink composition, cached source-pixel projections, exact material names and eligible GLB node names.
- `drawing/ArtworkTextureMapper.kt`: Android Bitmap adapter.
- `drawing/ArtworkMigration.kt`: foreground-envelope warp with nearest opaque pixel sampling; special clockwise rotation for the top-facing v1 beetle.
- `drawing/PaintDocument.kt`: optional immutable `mirrorAxisX`, shared by mirrored strokes, fill, and paper grain. Template supplies the approved butterfly centerline, which is slightly left of the square canvas center.
- `app/src/main/assets/v3/templates`: eight 1024×1024 PNG files (four outlines, four red-channel region masks).
- Tests: `ArtworkRasterMapperTest.kt`, `ArtworkMigrationTest.kt`, two additions to `PaintDocumentTest.kt`, test-only `PngTestPixels.kt` (no java.desktop dependency).

## Integration contracts

```kotlin
Template(context, species) // CURRENT_VERSION = 3
template.documentFrom(bitmap, sourceVersion): PaintDocument

ArtworkTextureMapper(templates: Map<Species, Template>) // preferred: share existing templates
ArtworkTextureMapper(context: Context)                 // convenience constructor
mapper.map(species: Species, bitmap: Bitmap): Map<String, Bitmap>

ArtworkRasterMapper.materialMeshes(species): Map<String, Set<String>>
```

The mapper borrows an input bitmap containing raw v3 paint pixels **without the outline**. It adds the approved protected ink itself. Returned bitmaps are newly allocated, independently owned by the caller. Recycle them once the engine no longer needs their pixel storage; the SDK's Texture copy/lifetime behavior is outside this mapper.

Keys are exact GLB material names. The corresponding sets contain actual GLB **node** names (also equal to their mesh names in these assets). Apply replacements only to those nodes. In particular:

- Beetle `warm_ivory_wax` only on `head_and_recurved_horn`, not the shell rims that share the original material.
- Ladybug `warm_brown_cuticle` only on `head`, not legs, abdomen, or antennae sharing the original material.

Replace only base-color texture, use a neutral white base-color factor, and retain the GLB normal/roughness and other PBR properties. Clone/instance shared material slots before modifying them.

Output dimensions are 1024×1024 per material, or 1024×512 for the caterpillar. Bitmap row zero corresponds to exported glTF V=0. No extra vertical flip is needed: the Blender export already inverted authored V. Projection indices are cached, but colors are sampled again for every call. Execute mapping on a worker.

## Mapping behavior

- Butterfly: exact approved crop-to-sheet and sheet-to-atlas transform, preserving all four independently painted wings and fixed tip/vein markings.
- Ladybug: separate left/right shell maps; the angular half-shell UV is warped through the approved row envelopes. Head uses its actual ellipsoid UV; collar uses its actual arch UV.
- Beetle: two independent material outputs from the single side-view elytron region. Height uses `cos(angle)^0.94`, matching the authored shell. Pronotum and long horn each receive their normalized source-profile map.
- Caterpillar: all ten documented longitudinal intervals, each sampling the corresponding drawing region. The side profile wraps around the continuous body, with exported V=.25 dorsal and .75 ventral. The opposite side repeats the same profile because the drawing defines one side.

No sample base-color images are read or used as substitutes for player pigment.

## Migration and memory

`documentFrom` returns a clean v3 document and does not mutate or recycle its input. Same-size v3 loads preserve pixels while removing pixels outside the current protected mask. Other versions/sizes are warped to the new silhouette. V1 beetle is rotated clockwise first so its former top-facing head becomes the new right-facing head.

Migration cannot preserve every geometric stroke location when the silhouette changes. The store/state integration **must retain the original PNG bytes before persisting the v3 result**, including draft originals, and identify migration to the user. The root agent owns that persistence and backup policy. This implementation retains per-pixel pigment rather than replacing an artwork with region average colors.

The approved 2048 source files are untouched. Runtime outlines were resized with Lanczos and masks with nearest-neighbor (never blended IDs). Four shared outline+region pairs now cost about 32 MiB instead of 128 MiB. Mask decode bitmaps are immediately recycled; there are no default bitmap copies, and `surface` aliases `outline`. Lazy mapper ink arrays add at most 16 MiB across all species. At 1024 atlas size, cached projection indices add about 38 MiB; the document's existing history budget remains 32 MiB. Temporary mapping arrays/textures and SDK PBR textures are additional allocations.

## Verification

- Local pure Kotlin/JUnit runner `.work/verify-v3-paint.ps1`: **28 tests passed**, last run completed successfully (`OK (28 tests)`, JUnit execution 2.06 s).
- Red evidence: initial mapper stub failed all five UV/ink tests; migration stub failed three non-empty migration tests; old center-based mirror failed the new off-center mirror test. Implementations then passed.
- Tests use asymmetric red/blue pixel marks and independently specified crop/UV landmarks, rather than comparing an equation with itself. Runtime 1024 output and cached repaint behavior are checked separately from the approved 2048 source geometry.
- `.work/v3-paint-asset-check.py`: passed all four actual GLB material/node bindings; exported butterfly root UVs, dorsal/ventral caterpillar UVs, shell seam/edge UVs; all four runtime masks use only red-channel region IDs and exclude every sampled protected locked pixel.
- Evidence JSON: `.work/v3-template-validation.json`, `.work/v3-glb-uv-validation.json`.
- `git diff --check` on owned tracked drawing/test files passed (only repository LF/CRLF advisory warnings).

Full Android build/Lint/unit suite belongs to the root integration. No headset rendering claim is made. Engine texture upload orientation, target-node material cloning, dynamic update performance, and perceived 3D appearance require the integrated SDK/device verification.

The root cleanup should delete old runtime `templates` and `v2/templates` when its coordinated legacy-asset removal runs; no drawing code here references those folders.
