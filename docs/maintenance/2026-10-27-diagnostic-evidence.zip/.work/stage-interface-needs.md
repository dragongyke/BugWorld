# Stage integration needs (2026-10-19)

Owner: dedicated Stage optimization chat. Shared checkout baseline f0d5823; started 2026-10-19T05:04:07Z. Changes remain uncommitted. No Gradle, APK, device operations performed here.

Stage-only diagnostics now touch GardenRuntime.kt, GardenScene.kt, SceneLighting.kt and add StageDiagnostics.kt / StageFrameStats.kt (+ StageFrameStatsTest). These preserve current runtime assets, lighting parameters and native ModelLibrary API. Parent may include them in its integration compile. Tag: BugWorldStagePerf.

Final candidate assets are validated in `.work/stage-optimization/candidate-v2/`; do not copy an earlier candidate. Ready manifest: `.work/stage-optimization/ready.json`. GLB SHA-256 97db51ae63cda21d1fd367a76aa0ed66a2565bbd5c399bc66ce64baf0337e2c5. Results and changed-file scope: docs/Stage-Optimization-Metrics.md. Candidate water overrides must become roughness .17, normalScale .65 (metallic 0, colour unchanged); the current SceneLighting runtime values remain baseline .24/.16 until coordinated integration.

Integration requires one atomic set: candidate garden.glb, candidate generated ApprovedGardenRoutes.kt and garden-routes.json (foreground log lowered 34 cm), rebuilt water-reflection.ktx, and candidate water parameters. Do not replace only garden.glb. Current validation scripts require garden to equal original approved GLB byte-for-byte, so a separate explicitly named derivative manifest must be accepted without weakening original/insect identity checks or rewriting the original approval manifest.

No request to change ModelLibrary.kt, PreviewScene.kt, BugWorldState.kt, Main.kt, build.gradle.kts or insects. Stage will not touch those files. Parent owns this round's integration build/device. Stage application integration/device work is gated on `.work/shared-space-integration-complete.json` newer than 2026-10-19T05:04:07Z.

Perf capability checked: pico-cli 0.5.0 internal; `perf --help` lists live/trace, but `perf trace --help` and `perf live --help` fail because Perf utilities 0.2.0 is absent. No setup/install attempted. Do not count CLI trace/FPS/GPU capture as performed.
