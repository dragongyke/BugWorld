# PICO native GLB APIs verified for BugWorld

2026-10-09. Read-only app/asset investigation; only `.work/v3-native-probe/` and this report were created. No Gradle app build, device install, asset conversion, or GLB mutation.

## API evidence

The probe uses **actual `com.pico.spatial.core:core:6.1.0` classes.jar**, SHA-256 `e69a8fe27a208c3276292efd95c3f1e6b5ca633aa80d133018c10cf48945a875`, extracted from the existing Gradle cache. It matches `.work/sdk/core.jar`. Native foundation is also extracted from its cached 6.1.0 AAR. `.work/sdk/foundation.jar` is a different jar; do not assume it is the native foundation.

Exact, standalone Kotlin skeleton: [NativeApiProbe.kt](v3-native-probe/NativeApiProbe.kt). Re-run without invoking Gradle: `powershell -File .work/v3-native-probe/compile.ps1`. Corrected probe compiled with exit 0 and produced `probe.jar` (11,551 bytes). The first compiler pass rejected only synthetic `controller.speed`/`controller.time`; explicit methods below are required.

The public website currently offers 6.1.9 and 6.0.0, not 6.1.0. Public docs below supply semantics; the 6.1.0 jar and isolated compilation supply API compatibility. `pico-cli knowledge list` reports no knowledge installed; nothing was installed.

## Direct loading: no Editor conversion required

```kotlin
val loaded = context.assets.open(path).use {
    Entity.loadSuspend(it, ModelFormat.GLTF)
}
// Better for these large packaged assets; add "glb" to androidResources.noCompress.
val loaded = context.assets.openFd(path).use {
    Entity.loadSuspend(it, ModelFormat.GLTF)
}
// Also supported:
val loaded = Entity.loadSuspend("asset://$path")
val instance = requireNotNull(loaded.clone(Entity.CloneOptions(
    recursive = true, shouldShareMaterialInstance = false
)))
```

`ModelFormat.GLTF` covers GLB; there is no `ModelFormat.GLB`. `clone` returns nullable, and defaults to **nonrecursive**. Explicit `recursive = true` is essential. Use suspend preload, then access/clone/mutate entities on the main thread. Do not synchronously load the 63 MB garden in the frame callback. InputStream loads buffer the complete file; AFD avoids that JVM copy and requires uncompressed APK assets. [Official direct GLB guide](https://github.com/Pico-Developer/PICO-Intelligent-Plugins/blob/main/pico-spatial-agentic-tools/skills/spatial-sdk-guideline/reference/resources-loading.md), [native loading API](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-entity/-companion/load-suspend.html), [clone options](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-entity/-clone-options/index.html).

## Materials and names

```kotlin
fun visit(entity: Entity) {
    val model = entity.components.get<ModelComponent>()
    if (model != null) for (index in 0 until model.materials.size) {
        val material = model.materials[index] as? PhysicallyBasedMaterial ?: continue
        if (material.getName() in approvedPaintMaterialNames) {
            material.setBaseColorTexture(replacementTexture)
        }
    }
    entity.getChildren().forEach(::visit)
}
val replacementTexture = TextureResource.create(bitmap)
```

There is **no public `Material.clone()`**. Clone the whole entity hierarchy with `shouldShareMaterialInstance = false`, then change only base color texture on the instance. This retains imported normal, roughness, metallic, AO, blending/culling, and any internal importer properties. The material methods are explicit `getName()`, `setBaseColorTexture()`, `getNormalTexture()`, `getRoughnessTexture()`, `getBaseColor()`, etc.; do not infer synthetic Kotlin properties from javap getter names. `model.materials[index] = replacementMaterial` is supported if replacement is needed, but rebuilding a material is unnecessary for this task.

Exact authored painting candidates, confirmed by parsing GLB JSON:

| Model | Material names |
|---|---|
| butterfly | `Continuous wax pigment • image PBR` |
| caterpillar | `Continuous wax pigment • image PBR` |
| beetle | `left_green_elytron`, `right_green_elytron`, `warm_ivory_wax`, `lavender_pronotum` |
| ladybug | `left_pink_wax`, `right_mint_wax`, `warm_brown_cuticle`, `ivory_collar_with_brown_smudge` |

These names now match the mapper contract. Use `ArtworkRasterMapper.materialMeshes(species)` to restrict eligible nodes: ladybug `warm_brown_cuticle` only paints `head`; beetle `warm_ivory_wax` only paints `head_and_recurved_horn`. Do not replace cuticle/eyes/membranes just because they have textures. Log imported names once on device to catch importer name normalization. Retain the replacement texture while referenced; close a previous replacement only after all target slots have switched. Do not close imported/shared texture resources individually as part of repainting.

## Animation

```kotlin
data class Clip(val owner: Entity, val resource: AnimationResource)
val clips = allEntities(instance).flatMap { node ->
    node.getAnimationResources().map { Clip(node, it) }
}
val clipName = clip.resource.getName()
val loopResource = clip.resource.repeat(SpatialAnimation.INFINITE) // INFINITE == -1
val player = clip.owner.playAnimation(loopResource, AnimationPlayConfig(
    transitionDuration = .18f,
    transitionMode = AnimationTransitionMode.CROSSFADE,
    blendLayer = 0,
    blendWeight = 1f,
))
player.setSpeed(.9f)
player.getSpeed()
player.getDuration()
player.getTime()
player.pause()
player.setTime(0f)
player.resume()
player.stop()
player.close()
// Or stop the animation owner:
clip.owner.stopAllAnimations()
```

Use `getAnimationResources()` and `resource.getName()`; **not** `availableAnimations` or `resource.name`. Playback has no public loop property. `repeat(count)` creates a new animation resource; create/cache repeating variants once rather than per frame, retain them while playing, and clean up owned variants when done. `SpatialAnimation.INFINITE = -1` is a public constant in 6.1.0. `findSkinnedMeshEntity(includeDisabled = true)` exists; newer `findSkeletonRootEntity()` does **not** exist in this jar. Enumerate resource owners through the hierarchy and play on the owner that supplied the resource. If several nodes expose the same name, inspect/log owners and avoid blindly scheduling 150 duplicate clips; runtime owner distribution is not provable from GLB alone.

`CROSSFADE` blends from a current playing clip. `STOP_AND_CROSSFADE` takes the current pose as the transition starting value. Avoid stopping the old clip before requesting `CROSSFADE`, since doing so removes the running pose to blend from. For hard cut use stop then new play. Final animation appearance/crossfade and clone-to-skeleton rebinding require device verification. [Transition semantics](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs.animation/-animation-transition-mode/index.html), [repeat](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs.resource/-animation-resource/repeat.html), [resource owners](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-entity/get-animation-resources.html).

All four insect GLBs have one skin: butterfly 68 skinned nodes, beetle 150, ladybug 139, caterpillar 92. Garden has zero skins and zero clips. Exact clip names match the review manifest: beetle/ladybug `flight`, `idle`, `takeoff`, `touch`, `walk`; butterfly `butterfly_antenna_groom`, `butterfly_fly`, `butterfly_idle_perch`, `butterfly_perch_touch`, `butterfly_startle`; caterpillar `caterpillar_crawl`, `caterpillar_explore`, `caterpillar_idle_breathe`, `caterpillar_recoil`, `caterpillar_touch_curiosity`.

## Opacity and light APIs

```kotlin
val opacity = OpacityControllerComponent(1f)
root.components.set(opacity)
opacity.opacity = amount.coerceIn(0f, 1f)

val sun = Entity().apply {
    components.set(DirectionalLightComponent(Color4(1f, .95f, .9f, 1f), 2000f, true).apply {
        castsShadowEnabled = true
        shadowDepthBias = .01f
        shadowFaceCullingMode = ShadowFaceCullingMode.BACK
        shadowProjectionType = ShadowProjectionType.Auto()
    })
    components.get<TransformComponent>()!!.setEulerAngles(EulerAngles(-45f, 30f, 0f))
}
val bulb = Entity().apply {
    components.set(PointLightComponent(Color4(1f, .9f, .8f, 1f), 100f, 2f))
}
val source = ImageBasedLightSource.Single(ktxCubemapTexture)
val iblEntity = Entity().apply { components.set(ImageBasedLightComponent(source, 0f)) }
meshEntity.components.set(ImageBasedLightReceiverComponent(iblEntity))
// For stage environment (different semantics from local IBL):
root.components.set(StageEnvironmentLightingComponent(source, 0f))
```

Opacity applies through descendants multiplicatively. Directional light points down local **-Z**, intensity is lux, and supports shadows. Point light intensity is lumens; radius is meters; **no point-light shadows**. Treat numeric examples as initial parameters, not visually validated equivalents to Blender. [Opacity](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-opacity-controller-component/index.html), [directional](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-directional-light-component/index.html), [point](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-point-light-component/index.html).

Local IBL requires an HDR environment cubemap in **`.ktx`**; arbitrary `.hdr`/PNG cannot be passed as a proven substitute. Receiver propagation to descendants is not stated in the API; attach to mesh entities when using local IBL. Intensity is `2^intensityExponent`. Stage environment IBL works in FULL, is inactive in MIXED, and blends with system IBL in PROGRESSIVE. [Local IBL](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-image-based-light-component/index.html), [receiver](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-image-based-light-receiver-component/index.html), [stage IBL](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-stage-environment-lighting-component/index.html).

`GroundShadowComponent(castsShadowEnabled = true, receivesShadowEnabled = true)` is an additional ground-shadow effect, **not** the directional-light shadow switch. It does not propagate: attach separately to each mesh entity that should cast/receive. [Ground shadow docs](https://developer.picoxr.com/spatial-api/6.1.9/spatialpack/core/com.pico.spatial.core.ecs/-ground-shadow-component/index.html).

## Material compatibility boundary

Every reviewed GLB declares **zero `extensionsRequired`**. Their optional extensions are:

| Asset | Optional extensions / exact concern |
|---|---|
| butterfly, caterpillar | `KHR_materials_specular`, factor 0.5 |
| beetle, ladybug | `KHR_materials_clearcoat`, factor 0.035 |
| garden | `KHR_materials_specular`, `KHR_materials_ior`, `KHR_materials_transmission`, `KHR_materials_emissive_strength` |

Native 6.1.0 public PBR APIs expose metallic/roughness/base color/AO/normal/emissive and blending; they do **not** expose clearcoat/transmission/IOR/specular-strength properties. No official native glTF extension support matrix was found in the bounded search. Do not infer importer support or failure from missing public setters. The GLB files can legally be loaded with these optional extensions ignored, but appearance may differ.

Most material extension differences are modest. Garden `dew` is **OPAQUE + transmission 0.88 + IOR 1.33**, so ignoring transmission can make droplets visibly opaque. `firefly` has emissive strength **24**; ignoring it dims the glow. `moss_01` uses core glTF **alphaMode BLEND** and an alpha texture, independently of IOR/specular. Do not force the whole garden to OPAQUE. `water` is OPAQUE with IOR 1.333, not transmission. No render proof has been produced by compilation; shadows, refraction, bloom, world lighting, and fog still require native equivalents/device inspection.
