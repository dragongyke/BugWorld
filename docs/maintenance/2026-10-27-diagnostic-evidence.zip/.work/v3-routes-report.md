# Approved v3 garden routes

Implemented `ApprovedGardenRoutes.pose(species: Species, index: Int, time: Float): NaturalPose` and `arrivalPose(species, index)`. `time` is elapsed seconds since that insect's arrival. The first 2.7 seconds exactly equal `arrivalPose`; the runtime must not add an extra height, orbit, or orientation correction.

## Files and provenance

- `app/src/main/java/com/bugworld/app/garden/ApprovedGardenRoutes.kt`: self-contained runtime path data and motion. No asset I/O in the render loop.
- `app/src/main/assets/v3/environment/garden-routes.json`: inspectable copy of sampled positions and surface normals.
- `scripts/assets_v3_routes.py`: reproducible Blender GLB raycast generator and independent validation of actual Kotlin poses.
- `app/src/test/java/com/bugworld/app/ApprovedGardenRoutesTest.kt`: seven pure JVM tests.
- Approved source: `assets-src/v3-review/garden/garden.glb`, SHA-256 `37db7de882b9768a416be37054a4d176a3cf8dbec578141eb7eb8bede99c3b34`.

Generation imports the exported GLB itself; no replacement environment is built. The source scan's log is offset from its nominal construction axis and contains a hollow, so a raycast search chooses a continuous shoulder instead of pretending the log is a cylinder. Thirteen paths each contain 101 position/normal samples. Normals use a 5 cm contact neighborhood to reduce orientation noise from fine scanned bark facets; positions remain on actual triangles. Maximum interpolation height error is 0.289 mm.

## Coordinates, orientation, and size

The knots already include the environment stage translation `(0, +0.36, -4.75)`. Blender `(x,y,z)` becomes runtime `(x,z+0.36,-y-4.75)`. This makes the approved Blender review camera `(0,-4.75,1.24)` coincide with the user's `(0,1.6,0)` view.

Native model fronts, confirmed with the SDK agent, are butterfly `-Z` and all other species `+X`. The PICO SDK uses `Ry(yaw) * Rx(pitch) * Rz(roll)`. The route constructs a surface frame and decomposes that exact order, including pitch and roll. Angles are degrees. No 90-degree compatibility rotation is needed.

Recommended instance scales remain butterfly `0.9`, beetle `0.75`, ladybug `0.55`, caterpillar `0.9`, assuming ModelLibrary normalizes the largest horizontal model span to 0.48 m and lowers the model's minimum Y to zero. Thus maximum horizontal spans are 0.432 / 0.360 / 0.264 / 0.432 m. The contact root is offset 3 mm along the fitted support normal.

## Slot allocation and behavior

The runtime must allocate globally unique slots 0 through 9; the route normalizes other indices modulo 10. Slots 0 through 2 use three distinct log areas for beetles, ladybugs, and butterflies, and three separate left-leaf areas for caterpillars. Slots 3 through 9 use the near right leaf's center and six peripheral areas. No pair of occupied slots shares the old reversed short path. Across all four species and independent ground-motion ages, tested center distances in the XZ plane exceed 0.47 m.

Ground insects rest, crawl about 12 cm, turn in place over four seconds, return, and turn back. Caterpillars remain on leaves. Butterflies alternate a perched rest, a stationary 0.8-second takeoff, and an 0.8 m high flight loop. Beetles and ladybugs finish a full crawl cycle, remain airborne-but-stationary for 1.4 seconds so the native takeoff clip can open shells, rise 0.32 m, complete a 0.20 m lateral loop toward the open foreground, return to the same anchor, and rest for 1.5 seconds while the landing clip closes. Lateral movement begins only after ascent and ends before descent. `airborne` and `moving` intentionally differ during stationary takeoff.

## Verification

Passed on 2026-10-09:

- `.work/verify-v3-routes.ps1`: `OK (7 tests)`. It compiles the production Kotlin and tests using cached Kotlin/JUnit without competing with root's full Gradle build.
- Birth stability for every species and slot; finite continuous positions over 120 seconds; foreground bounds; natural rest/motion; native-forward travel alignment; separate ground footprints at independently sampled ages; stationary shell opening and exact landing anchors.
- Actual Kotlin output: 48,040 samples, four species x ten slots x 1,201 times (0 through 120 seconds, 0.1-second increments), exported to `.work/v3-routes/kotlin-poses.csv`.
- Blender verification of 37,716 grounded poses: all outside the actual support triangles, with maximum nearest-surface distance **0.003036678 m**; reconstructed SDK up axes match the finite support patch.
- Blender verification of 4,732 cruise poses: minimum distance from solid scene geometry **0.141241238 m**, exceeding the 0.12 m check. Decorative moss/floating detail meshes are excluded. The earlier 2 mm collision of slot 7's beetle with the log tail was corrected by directing loops toward the open foreground; the clearance threshold was not relaxed.
- Latest proof: `.work/v3-routes/kotlin-surface-validation.json` and `.work/v3-routes/run-20261009-133127-4ee51b44.log`. `git diff --check` reports no whitespace errors (normal Windows line-ending notices only).

Reproduce generation with the local Blender runner and `scripts/assets_v3_routes.py --output-dir .work/v3-routes`; append `--verify-samples .work/v3-routes/kotlin-poses.csv` for validation only. Generate the CSV to completion before starting validation. The verify mode does not rewrite runtime route data.

## Scope of evidence

These checks establish contact-anchor placement, surface orientation, ground-slot spacing, trajectory continuity, and flight-root clearance against the real approved environment. They do not simulate animated foot/wing meshes or provide per-foot IK, swept animated-mesh collision, or inter-insect avoidance while flying. Detailed leg contact, wing opening timing, and visual comfort still need the integrated native runtime/device check. No full Gradle build or device operation was run by this subagent; root owns those checks.
