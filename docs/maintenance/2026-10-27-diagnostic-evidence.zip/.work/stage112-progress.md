# SDD ledger — plan: docs/Stage-112-Integration-Plan.md

Base: 9073842. Existing approved feature branch reused; no main changes.

- Task 1: in progress. Native scene bundle preferred to re-authoring materials at runtime; source-reviewed material graphs remain intact. Remove fixed review insects from runtime export.
- Task 1: bundle and HDR generation complete, mobile compilation passed; exact scene key Forest verified in package and official SDK template. Runtime verification pending.
- Task 2: routes generated on real GLB: 10 leaf lanes, 6 fallen-log lanes, 4 vertical trunk lanes. Maximum linear interpolation gap 0.758 mm; 8 route tests green. New beetle-habitat test failed on old behavior before implementation.
- Ruling: beetles crawl on wood instead of automatically taking flight, as requested. Update obsolete automatic-flight test to ladybugs only; invitation and touch behavior remain unchanged.
- Ruling: vertical trunk occupancy must measure 3D contact separation. New layout tests use 0.37 m minimum contact separation rather than old 0.47 m horizontal footprints; this is not a full-body collision guarantee, which remains a visual/animation validation item.
- Ruling: use current authorized feature branch and local ledger instead of a second checkout; user requires BugWorld-only outputs and existing work is clean. Risk: shared directory must be kept free of unrelated edits.
